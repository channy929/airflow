# Published at https://pypi.org/project/acryl-datahub-airflow-plugin/.
__package_name__ = "acryl-datahub-airflow-plugin"
__version__ = "1.3.1.2"
